package mytest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
//import io.github.bonigarcia.wdm.WebDriverManager;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LoginWithMultipleSetsOfData {

	@Test(dataProvider = "credentials")
	public void verifyLoginCredentials(String scenario, String username, String password) {
		
//		WebDriverManager.chromeDriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://demowebshop.tricentis.com/login");
		driver.findElement(By.id("")).sendKeys(username);
		driver.findElement(By.id("")).sendKeys(password);
		driver.findElement(By.cssSelector("input[value='Log in']")).click();
		
		if(scenario.equals("bothcorrect")) {
			WebElement account = driver.findElement(By.className("account"));
			Assert.assertTrue(account.isDisplayed(), "Login Not Success");
			
		}
		else if(scenario.equals("bothwrong")) {
			String errorMessage = driver.findElement(By.cssSelector(".message-error ul >li")).getText();
			Assert.assertEquals(errorMessage, "No Customer account found");
		}
		else if(scenario.equals("correctusername")) {
			String errorMessage = driver.findElement(By.cssSelector(".message-error ul >li")).getText();
			Assert.assertEquals(errorMessage, "The credentials provided are incorrect");
		}
		
		else {
			String errorMessage = driver.findElement(By.cssSelector(".message-error ul >li")).getText();
			Assert.assertEquals(errorMessage, "No Customer account found");
		}
		
	}
	
	@DataProvider(name = "credentials")
	public Object[][] getData() {
		
		
		return new Object[][] {
			{"bothcorrect", "sakinala@gmail.com", "p@ssword"},
			{"bothwrong", "adminuser@gmail.com", "adminpassword"},
			{"correctusername", "sakinala@gmail.com", "adminpassword"},
			{"correctpassword", "adminusername@gmail.com", "p@ssword"}
		};
		
	}
}
